<h1> Script de automatização de instalação de serviços de rede no GNU/Linux Ubuntu Server 18.04.x LTS</h1><br>

[![Instalação do Ubuntu Server](https://github.com/vaamonde/ubuntu-1804/blob/master/img/server-11.png)](https://www.youtube.com/watch?v=zDdCrqNhIXI)

<hr>

[![Instalação do LAMP Server](https://github.com/vaamonde/ubuntu-1804/blob/master/img/server-12.png)](https://www.youtube.com/watch?v=6EFUu-I3u4s&)

<hr>

[![Instalação do Wordpress](https://github.com/vaamonde/ubuntu-1804/blob/master/img/server-13.png)](https://www.youtube.com/watch?v=Fs2B7kLdlm4&t)

<hr>

[![Instalação do Webmin](https://github.com/vaamonde/ubuntu-1804/blob/master/img/server-14.png)](https://www.youtube.com/watch?v=rKTFI9s_YNY)

<hr>

[![Instalação do Netdata](https://github.com/vaamonde/ubuntu-1804/blob/master/img/server-15.png)](https://www.youtube.com/watch?v=TdTTgztYVKc)
